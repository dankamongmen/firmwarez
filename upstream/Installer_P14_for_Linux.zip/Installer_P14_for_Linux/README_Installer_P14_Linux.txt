************************************

Installer for Linux

LSI Corporation SAS2FLASH Release

************************************
=============================
Contents-
=============================
Installer fOr Linux (SAS2FLASH)    :  \sas2flash_linux_i686_x86-64_rel\sas2flash    Version:14.00.00.00        Release Date:04-JULY-12
Installer fOr Linux (SAS2FLASH)    :  \sas2flash_linux_ppc64_rel\sas2flash          Version:14.00.00.00        Release Date:04-JULY-12
README_FOR_Installer_P10_Linux.txt
SAS2Flash_ReferenceGuide.pdf
SAS2FLASH_Phase_14.0-14.00.00.00.pdf



Installation:
=============

SAS2FLASH is stand-alone binary and can be executed from any location on a file system.For more details on installer please refer to the SAS2FLASH User manual included in this package.


